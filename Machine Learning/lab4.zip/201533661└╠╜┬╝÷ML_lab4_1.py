import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import os,sys
np.set_printoptions(threshold=sys.maxsize)
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import LabelEncoder
'''
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import DBSCAN

from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import normalize
from sklearn.decomposition import PCA
'''

##Import train Data & Preprocessing##
readDt=pd.read_csv(os.getcwd()+'\\play_golf.csv',encoding = "ISO-8859-1")
X=readDt.drop(columns=['play Golf']).head(100)#test:predictors
y=readDt['play Golf'].head(100)

caseOutlook=['rainy','overcast','sunny']
caseTemp=['hot','mild','cool']
caseHumidity=['high','normal']
caseWind=["True",'False']

countYes=0
countNo=0
P_Outlook=[[0,0],[0,0],[0,0]]
P_Temp=[[0,0],[0,0],[0,0]]
P_Humidity=[[0,0],[0,0],[0,0]]
P_Wind=[[0,0],[0,0],[0,0]]

#print(readDt.loc[0,'play Golf'])

for i in range(len(readDt)):
    if str(readDt.loc[i,'play Golf']) == 'yes':
        countYes=countYes+1
        #count Outlook
        if readDt.loc[i,'Outlook'] == caseOutlook[0]:
            P_Outlook[0][0]=P_Outlook[0][0]+1
        elif readDt.loc[i,'Outlook'] == caseOutlook[1]:
            P_Outlook[1][0]=P_Outlook[1][0]+1
        elif readDt.loc[i,'Outlook'] == caseOutlook[2]:
            P_Outlook[2][0]=P_Outlook[2][0]+1
        #count Temp
        if readDt.loc[i,'Temp'] == caseTemp[0]:
            P_Temp[0][0]=P_Temp[0][0]+1
        elif readDt.loc[i,'Temp'] == caseTemp[1]:
            P_Temp[1][0]=P_Temp[1][0]+1
        elif readDt.loc[i,'Temp'] == caseTemp[2]:
            P_Temp[2][0]=P_Temp[2][0]+1
        #count Himidity
        if readDt.loc[i,'Humidity'] == caseHumidity[0]:
            P_Humidity[0][0]=P_Humidity[0][0]+1
        elif readDt.loc[i,'Humidity'] == caseHumidity[1]:
            P_Humidity[1][0]=P_Humidity[1][0]+1
        #count Wind
        if readDt.loc[i,'Wind'].astype(str) == caseWind[0]:
            P_Wind[0][0]=P_Wind[0][0]+1
        elif readDt.loc[i,'Wind'].astype(str) == caseWind[1]:
            P_Wind[1][0]=P_Wind[1][0]+1
    else:#elif str(readDt.loc[i,'play Golf']) is 'no':
        countNo=countNo+1
        #count Outlook
        if readDt.loc[i,'Outlook'] == caseOutlook[0]:
            P_Outlook[0][1]=P_Outlook[0][1]+1
        elif readDt.loc[i,'Outlook'] == caseOutlook[1]:
            P_Outlook[1][1]=P_Outlook[1][1]+1
        elif readDt.loc[i,'Outlook'] == caseOutlook[2]:
            P_Outlook[2][1]=P_Outlook[2][1]+1
        #count Temp
        if readDt.loc[i,'Temp'] == caseTemp[0]:
            P_Temp[0][1]=P_Temp[0][1]+1
        elif readDt.loc[i,'Temp'] == caseTemp[1]:
            P_Temp[1][1]=P_Temp[1][1]+1
        elif readDt.loc[i,'Temp'] == caseTemp[2]:
            P_Temp[2][1]=P_Temp[2][1]+1
        #count Himidity
        if readDt.loc[i,'Humidity'] == caseHumidity[0]:
            P_Humidity[0][1]=P_Humidity[0][1]+1
        elif readDt.loc[i,'Humidity'] == caseHumidity[1]:
            P_Humidity[1][1]=P_Humidity[1][1]+1
        #count Wind
        if readDt.loc[i,'Wind'].astype(str) == caseWind[0]:
            P_Wind[0][1]=P_Wind[0][1]+1
        elif readDt.loc[i,'Wind'].astype(str) == caseWind[1]:
            P_Wind[1][1]=P_Wind[1][1]+1

#devided by yes/no count
for i in range(len(P_Outlook)):
    for j in range(2):
        if j == 0:
            P_Outlook[i][j]=P_Outlook[i][j]/countYes
        elif j == 1:
            P_Outlook[i][j]=P_Outlook[i][j]/countNo
for i in range(len(P_Temp)):
    for j in range(2):
        if j == 0:
            P_Temp[i][j]=P_Temp[i][j]/countYes
        elif j == 1:
            P_Temp[i][j]= P_Temp[i][j]/countNo
for i in range(len(P_Humidity)):
    for j in range(2):
        if j == 0:
            P_Humidity[i][j]=P_Humidity[i][j]/countYes
        elif j == 1:
            P_Humidity[i][j]= P_Humidity[i][j]/countNo
for i in range(len(P_Wind)):
    for j in range(2):
        if j == 0:
            P_Wind[i][j]=P_Wind[i][j]/countYes
        elif j == 1:
            P_Wind[i][j]= P_Wind[i][j]/countNo


pYes=P_Outlook[2][0]*P_Temp[2][0]*P_Humidity[0][0]*P_Wind[1][0]
pYes=pYes*(countYes/len(readDt))
pNo=P_Outlook[2][1]*P_Temp[2][1]*P_Humidity[0][1]*P_Wind[1][1]
pNo=pNo*(countYes/len(readDt))
print('P(Yes)=',pYes)
print('P(No)=',pNo)
if pYes > pNo:
    print('play Golf?: yes!!')
elif pYes <= pNo:
    print('play Golf?: no!!')
