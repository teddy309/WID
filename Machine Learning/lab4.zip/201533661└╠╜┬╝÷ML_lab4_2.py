import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import os,sys
np.set_printoptions(threshold=sys.maxsize)
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import LabelEncoder
'''
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import DBSCAN

from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import normalize
from sklearn.decomposition import PCA
'''

##Import train Data & Preprocessing##
readDt=pd.read_csv(os.getcwd()+'\\go_university.csv',encoding = "ISO-8859-1")
#print(readDt)


caseUniversity=['enter','none']
caseDad=['university','high']
caseMom=['university','high']
caseChild=['boy','girl']

countYes=0
countNo=0
P_Dad=[[0,0],[0,0]]
P_Mom=[[0,0],[0,0]]
P_Child=[[0,0],[0,0]]

#print(readDt.loc[0,'play Golf'])

for i in range(len(readDt)):
    if str(readDt.loc[i,'university']) == 'enter':
        countYes=countYes+1
        #count dad
        if readDt.loc[i,'dad'] == caseDad[0]:
            P_Dad[0][0]=P_Dad[0][0]+1
        elif readDt.loc[i,'dad'] == caseDad[1]:
            P_Dad[1][0]=P_Dad[1][0]+1
        #count mom
        if readDt.loc[i,'mom'] == caseMom[0]:
            P_Mom[0][0]=P_Mom[0][0]+1
        elif readDt.loc[i,'mom'] == caseMom[1]:
            P_Mom[1][0]=P_Mom[1][0]+1
        #count child
        if readDt.loc[i,'child'] == caseChild[0]:
            P_Child[0][0]=P_Child[0][0]+1
        elif readDt.loc[i,'child'] == caseChild[1]:
            P_Child[1][0]=P_Child[1][0]+1
    else:#elif str(readDt.loc[i,'play Golf']) is 'no':
        countNo=countNo+1
        #count dad
        if readDt.loc[i,'dad'] == caseDad[0]:
            P_Dad[0][1]=P_Dad[0][1]+1
        elif readDt.loc[i,'dad'] == caseDad[1]:
            P_Dad[1][1]=P_Dad[1][1]+1
        #count mom
        if readDt.loc[i,'mom'] == caseMom[0]:
            P_Mom[0][1]=P_Mom[0][1]+1
        elif readDt.loc[i,'mom'] == caseMom[1]:
            P_Mom[1][1]=P_Mom[1][1]+1
        #count child
        if readDt.loc[i,'child'] == caseChild[0]:
            P_Child[0][1]=P_Child[0][1]+1
        elif readDt.loc[i,'child'] == caseChild[1]:
            P_Child[1][1]=P_Child[1][1]+1

#devided by yes/no count
for i in range(len(P_Dad)):
    for j in range(2):
        if j == 0:
            P_Dad[i][j]=P_Dad[i][j]/countYes
        elif j == 1:
            P_Dad[i][j]=P_Dad[i][j]/countNo
for i in range(len(P_Mom)):
    for j in range(2):
        if j == 0:
            P_Mom[i][j]=P_Mom[i][j]/countYes
        elif j == 1:
            P_Mom[i][j]= P_Mom[i][j]/countNo
for i in range(len(P_Child)):
    for j in range(2):
        if j == 0:
            P_Child[i][j]=P_Child[i][j]/countYes
        elif j == 1:
            P_Child[i][j]= P_Child[i][j]/countNo


pYes=P_Dad[0][0]*P_Mom[0][0]*P_Child[1][0]
pYes=pYes*(countYes/len(readDt))
pNo=P_Dad[0][1]*P_Mom[0][1]*P_Child[1][1]
pNo=pNo*(countYes/len(readDt))
print('P(enter)=',pYes)
print('P(none)=',pNo)
if pYes > pNo:
    print('go university?: yes!!')
elif pYes <= pNo:
    print('go university?: no!!')
