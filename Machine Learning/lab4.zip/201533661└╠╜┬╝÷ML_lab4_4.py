import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import os,sys
np.set_printoptions(threshold=sys.maxsize)
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import LabelEncoder
'''
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import DBSCAN

from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import normalize
from sklearn.decomposition import PCA
'''
#index: study=1,rest=2, walk=3, eat=3
transMat=[[0.60,0.15,0.05,0.20],[0.05,0.80,0.10,0.05],[0.05,0.15,0.50,0.30],[0.20,0.15,0.15,0.50]]
observation=['rest','eat','study','study','walk','rest']
probability=1
print('transition Matrix:')
print(transMat)
print('observation:',observation)

for i in range(len(observation)-1):
    if observation[i] is 'study':
        observation[i]=0
        if observation[i+1] is 'study':
            probability=probability*transMat[0][0]
        elif observation[i+1] is 'rest':
            probability=probability*transMat[0][1]
        elif observation[i+1] is 'walk':
            probability=probability*transMat[0][2]
        elif observation[i+1] is 'eat':
            probability=probability*transMat[0][3]
    elif observation[i] is 'rest':
        observation[i]=1
        if observation[i+1] is 'study':
            probability=probability*transMat[0][0]
        elif observation[i+1] is 'rest':
            probability=probability*transMat[0][1]
        elif observation[i+1] is 'walk':
            probability=probability*transMat[0][2]
        elif observation[i+1] is 'eat':
            probability=probability*transMat[0][3]
    elif observation[i] is 'walk':
        observation[i]=2
        if observation[i+1] is 'study':
            probability=probability*transMat[0][0]
        elif observation[i+1] is 'rest':
            probability=probability*transMat[0][1]
        elif observation[i+1] is 'walk':
            probability=probability*transMat[0][2]
        elif observation[i+1] is 'eat':
            probability=probability*transMat[0][3]
    elif observation[i] is 'eat':
        observation[i]=3
        if observation[i+1] is 'study':
            probability=probability*transMat[0][0]
        elif observation[i+1] is 'rest':
            probability=probability*transMat[0][1]
        elif observation[i+1] is 'walk':
            probability=probability*transMat[0][2]
        elif observation[i+1] is 'eat':
            probability=probability*transMat[0][3]
print(observation)
print('Answer(Probability)=',probability)

