import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import warnings
warnings.filterwarnings("ignore")#ignore warnings

##Read heart.csv data & Preprocessing Step##
df=pd.read_csv(os.getcwd()+"\\heart.csv")
X=df.drop(columns=['target'])
y=df['target'].values


##split into 10-Folds##
from sklearn.model_selection import train_test_split
X_train=[pd.DataFrame(columns=X.columns) for i in range(10)]
X_test=[pd.DataFrame(columns=X.columns) for i in range(10)]
y_train=[pd.Series([]) for i in range(10)]
y_test=[pd.Series([]) for i in range(10)]
for i in range(10):#
    trainX,testX,trainY,testY=train_test_split(X,y,test_size=0.2,random_state=None,stratify=y)
    X_train[i]=trainX
    X_test[i]=testX
    y_train[i]=trainY
    y_test[i]=testY
    #print(y_test[i][5])#ok
#print(y_train[0])
#print(y_test[0])
    

##Model's Parameters:stored in an array##
#Decision Tree
pCriterion=['gini','entropy']
#Logistic Regression
pSolver=['liblinear','lbfgs','sag']
pMax_iter=[50,100,200]
#SVM
pCvalues=[0.1,1.0,10.0]
pKernel=['linear','poly','rbf','sigmoid']
pGamma=['auto',10,100]
#Model info
modelName='SVM'
xName=pCvalues
yName=pGamma

kernelIndex=1
gammaIndex=1
cIndex=0


from sklearn.model_selection import cross_val_score#
from sklearn.metrics import accuracy_score
'''
from sklearn.model_selection import cross_val_score
##Decision Tree Classifier prediction: 10-Fold Cross Validation sampling##
from sklearn.tree import DecisionTreeClassifier
clf_DT=DecisionTreeClassifier(random_state=0,criterion='gini')#Parameters:criterion(gini,entropy)
DT_score=cross_val_score(clf_DT,X,y,cv=10)#model, train, target, cross validation
print('DT_scores average:{}'.format(np.mean(DT_score)))

##SVM prediction: 10-Fold Cross Validation sampling##
from sklearn.svm import SVC
clf_SVC=SVC(C=0.1,kernel='linear',gamma=100,degree=3,tol=0.001)#Parameters:C(0.1,1.0,10.0),kernel(linear,poly,rbf,sigmoid),gamma(0,10,100)
SVC_score=cross_val_score(clf_SVC,X,y,cv=10)# model, train, target, cross validation
print('SVC_scores average:{}'.format(np.mean(SVC_score)))
##Logistic Regression prediction##
from sklearn.linear_model import LogisticRegression
score=np.empty([10])
predY=[pd.Series([]) for i in range(10)]
logisticRegr=LogisticRegression(solver='lbfgs',max_iter=50)#Parameters:solver(liblinear,lbfgs,sag),max_iter(50,100,200)
for i in range(10):
    logisticRegr.fit(X_train[i],y_train[i])
    predY[i]=logisticRegr.predict(X_test[i])
    #print(accuracy_score(y_test[i],predY))
    print(logisticRegr.score(X_test[i],y_test[i]))
    score[i]=logisticRegr.score(X_test[i],y_test[i]).astype('float64')
print(np.mean(score))#print average of model's score
index_bestFold=list(score).index(np.amax(score))

'''
print('here')
##SVM prediction: 10-Fold Cross Validation sampling##
from sklearn.svm import SVC
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import MinMaxScaler
score=np.empty([10])
predY=[pd.Series([]) for i in range(10)]
clf_SVC=SVC(C=pCvalues[cIndex],kernel=pKernel[kernelIndex],gamma=pGamma[gammaIndex],degree=3,tol=0.001)#Parameters:C(0.1,1.0,10.0),kernel(linear,poly,rbf,sigmoid),gamma(0,10,100)
pipe=Pipeline([("scaler",MinMaxScaler()),("svm",clf_SVC)])
#cv=KFold(10,shuffle=True, random_state=0)
'''
for i in range(10):
    clf_SVC.fit(X_train[i],y_train[i])
    predY[i]=clf_SVC.predict(X_test[i])
    print(clf_SVC.score(X_test[i],y_test[i]))
    score[i]=clf_SVC.score(X_test[i],y_test[i]).astype('float64')
    '''
for i in range(10):
    pipe.fit(X_train[i],y_train[i])
    predY[i]=clf_SVC.predict(X_test[i])
    print(pipe.score(X_test[i],y_test[i]))
    score[i]=pipe.score(X_test[i],y_test[i]).astype('float64')
print(np.mean(score))#print average of model's score
index_bestFold=list(score).index(np.amax(score))


##seaborn Visualization:Confusion Matrix##
import seaborn as sn
confusion_matrix=pd.crosstab(y_test[index_bestFold],predY[index_bestFold],rownames=['Actual'],colnames=['Predicted'],margins=True)
sn.heatmap(confusion_matrix,annot=True)
plt.title("ConfusionMatrix(model:{}, fold:{}, kernel:{}, g:{})".format(modelName,index_bestFold,pKernel[kernelIndex],pGamma[gammaIndex]))
plt.show()

##3D bar chart with matplotlib##
from mpl_toolkits.mplot3d import axes3d
from matplotlib import style
style.use('ggplot')
fig=plt.figure()
ax1=fig.add_subplot(111,projection='3d')

#LogisticRegression
xTicks=[1,2,3]#parameter1
x3=[]
for i in range(len(xTicks)):
    for j in range(len(xTicks)):
        x3.append(xTicks[i])

yTicks=[1,2,3]#parameter2
y3=yTicks*len(yTicks)
z3 = np.zeros(9)
z3=np.zeros(9)
dx=np.ones(9)
dy=np.ones(9)
dz=[]#display result(accuracy score) of each parameter1,2
'''
for i in range(len(xTicks)):
    for j in range(len(yTicks)):
        clf_SVC=SVC(C=pCvalues[cIndex],kernel='poly',gamma=pGamma[gammaIndex],degree=3,tol=0.001)#Parameters:C(0.1,1.0,10.0),kernel(linear,poly,rbf,sigmoid),gamma(0,10,100)
        dz.append(np.mean(cross_val_score(clf_SVC,X,y,cv=10)))#
        '''
for i in range(len(xTicks)):
    for j in range(len(yTicks)):
        pipe=Pipeline([("scaler",MinMaxScaler()),("svm",clf_SVC)])
        dz.append(np.mean(cross_val_score(pipe,X,y,cv=10)))#
print(type(dz[0]))
print(len(x3),len(y3),len(dz))
print(type(x3[0]))
print(type(y3[0]))
print(x3)
print(y3)
print(dz)
ax1.bar3d(x3,y3,z3,dx,dy,dz)
plt.xticks(xTicks,xName)
plt.yticks(yTicks,yName)
ax1.set_xlabel('parameter1: {}'.format(str(xTicks)))
ax1.set_ylabel('parameter2: {}'.format(str(yTicks)))
ax1.set_zlabel('accuracy score')
plt.title('Model: {},kernel: {}'.format(modelName,pKernel[kernelIndex]))
plt.show()
