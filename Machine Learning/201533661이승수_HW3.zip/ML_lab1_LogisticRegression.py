import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import warnings
warnings.filterwarnings("ignore")#ignore warnings

##Read heart.csv data & Preprocessing Step##
df=pd.read_csv(os.getcwd()+"\\heart.csv")
X=df.drop(columns=['target'])
y=df['target'].values

'''
from sklearn.model_selection import cross_val_score
##Decision Tree Classifier prediction: 10-Fold Cross Validation sampling##
from sklearn.tree import DecisionTreeClassifier
clf_DT=DecisionTreeClassifier(random_state=0,criterion='gini')#Parameters:criterion(gini,entropy)
DT_score=cross_val_score(clf_DT,X,y,cv=10)#model, train, target, cross validation
print('DT_scores average:{}'.format(np.mean(DT_score)))
##SVM prediction: 10-Fold Cross Validation sampling##
from sklearn.svm import SVC
clf_SVC=SVC(C=0.1,kernel='linear',gamma=100,degree=3,tol=0.001)#Parameters:C(0.1,1.0,10.0),kernel(linear,poly,rbf,sigmoid),gamma(0,10,100)
SVC_score=cross_val_score(clf_SVC,X,y,cv=10)# model, train, target, cross validation
print('SVC_scores average:{}'.format(np.mean(SVC_score)))
##Logistic Regression prediction##
from sklearn.linear_model import LogisticRegression
logisticRegr=LogisticRegression(solver='lbfgs',max_iter=50)#Parameters:solver(liblinear,lbfgs,sag),max_iter(50,100,200)
logisticRegr.fit(X_train,y_train)
LogisticRegr_score=cross_val_score(logisticRegr,X,y,cv=10)# model, train, target, cross validation
print('LogisticRegression_scores average:{}'.format(np.mean(LogisticRegr_score)))
'''

##split into 10-Folds##
from sklearn.model_selection import train_test_split
X_train=[pd.DataFrame(columns=X.columns) for i in range(10)]
X_test=[pd.DataFrame(columns=X.columns) for i in range(10)]
y_train=[pd.Series([]) for i in range(10)]
y_test=[pd.Series([]) for i in range(10)]
for i in range(10):#
    trainX,testX,trainY,testY=train_test_split(X,y,test_size=0.2,random_state=None,stratify=y)
    X_train[i]=trainX
    X_test[i]=testX
    y_train[i]=trainY
    y_test[i]=testY
    #print(y_test[i][5])#ok
#print(y_train[0])
#print(y_test[0])

'''
##10-Fold Cross Validation sampling&prediction ##
from sklearn import linear_model
from sklearn.model_selection import cross_val_predict
#testX=X.iloc[:150]
#testY=y[:150]
lasso=linear_model.Lasso()
predY=cross_val_predict(lasso,X,y,cv=10)
#print(np.array_equal(predY,y[:150].astype('float64')))
#print(predY.dtype)
#print(y[:150].astype('float64').dtype)
#print(predY)
#print(y)
'''

'''
from sklearn.model_selection import cross_val_score
##Decision Tree Classifier prediction: 10-Fold Cross Validation sampling##
from sklearn.tree import DecisionTreeClassifier
clf_DT=DecisionTreeClassifier(random_state=0,criterion='gini')#Parameters:criterion(gini,entropy)
DT_score=cross_val_score(clf_DT,X,y,cv=10)#model, train, target, cross validation
print('DT_scores average:{}'.format(np.mean(DT_score)))
##SVM prediction: 10-Fold Cross Validation sampling##
from sklearn.svm import SVC
clf_SVC=SVC(C=0.1,kernel='linear',gamma=100,degree=3,tol=0.001)#Parameters:C(0.1,1.0,10.0),kernel(linear,poly,rbf,sigmoid),gamma(0,10,100)
SVC_score=cross_val_score(clf_SVC,X,y,cv=10)# model, train, target, cross validation
print('SVC_scores average:{}'.format(np.mean(SVC_score)))
'''
##Model's Parameters:stored in an array##
#Decision Tree
pCriterion=['gini','entropy']
#Logistic Regression
pSolver=['liblinear','lbfgs','sag']
pMax_iter=[50,100,200]
#SVM
pCvalues=[0.1,1.0,10.0]
pKernel=['linear','poly','rbf','sigmoid']
pGamma=[0,10,100]
#Model info
modelName='LogisticRegression'
xName=pSolver
yName=pMax_iter

solverIndex=2
iterIndex=2

##Logistic Regression prediction##
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score#
from sklearn.metrics import accuracy_score
score=np.empty([10])
predY=[pd.Series([]) for i in range(10)]
logisticRegr=LogisticRegression(solver=pSolver[solverIndex],max_iter=pMax_iter[iterIndex])#Parameters:solver(liblinear,lbfgs,sag),max_iter(50,100,200)
for i in range(10):
    logisticRegr.fit(X_train[i],y_train[i])
    predY[i]=logisticRegr.predict(X_test[i])
    #print(accuracy_score(y_test[i],predY))
    print(logisticRegr.score(X_test[i],y_test[i]))
    score[i]=logisticRegr.score(X_test[i],y_test[i]).astype('float64')
print(np.mean(score))#print average of model's score
index_bestFold=list(score).index(np.amax(score))

##seaborn Visualization:Confusion Matrix##
import seaborn as sn
confusion_matrix=pd.crosstab(y_test[index_bestFold],predY[index_bestFold],rownames=['Actual'],colnames=['Predicted'],margins=True)
sn.heatmap(confusion_matrix,annot=True)
plt.title("ConfusionMatrix(model:{}, fold:{},solver:{}, max iter:{})".format(modelName,index_bestFold,pSolver[solverIndex],pMax_iter[iterIndex]))
plt.show()      

##3D bar chart with matplotlib##
from mpl_toolkits.mplot3d import axes3d
from matplotlib import style
style.use('ggplot')
fig=plt.figure()
ax1=fig.add_subplot(111,projection='3d')

#LogisticRegression
xTicks=[1,2,3]#parameter1
x3=[]
for i in range(len(xTicks)):
    for j in range(len(xTicks)):
        x3.append(xTicks[i])

yTicks=[1,2,3]#parameter2
y3=yTicks*len(yTicks)
z3 = np.zeros(9)
z3=np.zeros(9)
dx=np.ones(9)
dy=np.ones(9)
dz=[]#display result(accuracy score) of each parameter1,2
for i in range(len(xTicks)):
    for j in range(len(yTicks)):
        logisticRegr=LogisticRegression(solver=pSolver[i],max_iter=pMax_iter[j])#Parameters:solver(liblinear,lbfgs,sag),max_iter(50,100,200)
        dz.append(np.mean(cross_val_score(logisticRegr,X,y,cv=10)))#
print(type(dz[0]))
print(len(x3),len(y3),len(dz))
print(type(x3[0]))
print(type(y3[0]))
print(x3)
print(y3)
print(dz)
ax1.bar3d(x3,y3,z3,dx,dy,dz)
plt.xticks(xTicks,xName)
plt.yticks(yTicks,yName)
ax1.set_xlabel('parameter1: {}'.format(str(xTicks)))
ax1.set_ylabel('parameter2: {}'.format(str(yTicks)))
ax1.set_zlabel('accuracy score')
plt.title('Model:{}, solver:{}'.format(modelName,pSolver[solverIndex]))
plt.show()

