from scipy import io
import seaborn as sn
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import os
import warnings

from sklearn.model_selection import train_test_split
from sklearn.ensemble import VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.preprocessing import MinMaxScaler

warnings.filterwarnings("ignore")
mnist=io.loadmat(os.getcwd()+"\\mnist-original.mat")
## divide the dataset It's too big so Using 10%
x_train, x ,y_train, y=train_test_split(mnist["data"].T,mnist["label"][0], test_size=0.1,random_state=0)
## D1 data get 50% of to train
x_train, x_test, y_train, y_test=train_test_split(x,y, test_size=0.5,random_state=0)
## D2 and D3 gets data of D1 's half data
x_test, x_etest, y_test, y_etest=train_test_split(x_test,y_test, test_size=0.5, random_state=0)

## reduce the data scale
scaler=MinMaxScaler()
x_train=scaler.fit_transform(x_train)

log=LogisticRegression(random_state=1)
svm_linear=SVC(kernel='linear',probability=True, random_state=1)
svm_rbf=SVC(kernel='rbf',probability=True,random_state=1)

voting_clf=VotingClassifier(estimators=[('lr',log),('svm_l',svm_linear),('svm_r',svm_rbf)],voting='soft')
voting_clf.fit(x_train,y_train)

from sklearn.metrics import accuracy_score
for clf in (log, svm_linear, svm_rbf,voting_clf):
    clf.fit(x_train, y_train)
    y_pred = clf.predict(x_test)
    print(clf.__class__.__name__, accuracy_score(y_test, y_pred))


confusion_matrix=pd.crosstab(y_test,y_pred)
sn.heatmap(confusion_matrix,annot=True,fmt="d")
plt.show()
