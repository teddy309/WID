import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import warnings
warnings.filterwarnings("ignore")#ignore warnings

def scatter_plot(feature,target):
    plt.figure(figsize=((8,4)))
    plt.scatter(data[feature],data[target],c='black')
    plt.xlabel('Money spent on {} ads ($)'.format(feature))
    plt.ylabel('{} ($k)'.format(target))
    plt.show()
##read csv data & seperate predictor/target 
from sklearn.model_selection import cross_val_score
data=pd.read_csv(os.getcwd()+"\\Advertising.csv")
data.head()
data.drop(['Unnamed: 0'],axis=1,inplace=True)#drop useless feature
data.head()
print(data)
#scatter_plot('TV','Sales')#OK
x5=data.drop(['Sales'],axis=1)
y=data['Sales'].values.reshape(-1,1)

##Linear Regression
from sklearn.linear_model import LinearRegression
lin_reg=LinearRegression()
MSE5=cross_val_score(lin_reg,x5,y,scoring='neg_mean_squared_error',cv=5)
mean_MSE=np.mean(MSE5)
print('best score of Linear Regressor: ',np.max(MSE5))#mean score of Linear Regression

from sklearn.model_selection import GridSearchCV
#Ridge Regression
from sklearn.linear_model import Ridge
ridge=Ridge()
parameters={'alpha':[1e-15,1e-10,1e-8,1e-4,1e-3,1e-2,1,5,10,20]}
ridge_regressor=GridSearchCV(ridge,parameters,scoring='neg_mean_squared_error',cv=5)
ridge_regressor.fit(x5,y)
print('best parameters of Ridge Regressor: ',ridge_regressor.best_params_)#best parameters of Ridge Regression
print('best score of Ridge Regressor: ',ridge_regressor.best_score_)#best score of Ridge Regression

##Lasso Regression
from sklearn.linear_model import Lasso
lasso=Lasso()
parameters={'alpha':[1e-15,1e-10,1e-8,1e-4,1e-3,1e-2,1,5,10,20]}
lasso_regressor=GridSearchCV(lasso,parameters,scoring='neg_mean_squared_error',cv=5)
lasso_regressor.fit(x5,y)
print('best parameters of Lasso Regressor: ',lasso_regressor.best_params_)#best parameters of Lasso Regression
print('best score of Lasso Regressor: ',lasso_regressor.best_score_)#best score of Lasso Regression

##Elastic Net Regression
from sklearn.linear_model import ElasticNet
ENscore=[]
for i in range(11):
    L1=round(i*0.1,2)#L1:0.i format
    elastic=ElasticNet(random_state=0,l1_ratio=L1,alpha=1.0)#L1(0~1),alpha(ramda)
    parameters={'alpha':[1e-15,1e-10,1e-8,1e-4,1e-3,1e-2,1,5,10,20]}
    elasticNet_regressor=GridSearchCV(elastic,parameters,scoring='neg_mean_squared_error',cv=5)
    elasticNet_regressor.fit(x5,y)
    print('case [l1_ratio={}]:'.format(L1))
    print('best parameters of Elastic Net Regressor[{}]: {}'.format(L1,elasticNet_regressor.best_params_))#best parameters of Elastic Net Regression
    ENscore.append(elasticNet_regressor.best_score_)
    print('score of Elastic Net Regressor[{}]: {}'.format(L1,ENscore[i]))#best score of Elastic Net Regression
print('best score of Elastic Net Regressor:',np.max(ENscore))
print('best scored Regression model score:{}'.format(max(mean_MSE,ridge_regressor.best_score_,lasso_regressor.best_score_,np.max(ENscore))))
