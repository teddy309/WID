import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import warnings
warnings.filterwarnings("ignore")#ignore warnings

def scatter_plot(feature,target):
    plt.figure(figsize=((8,4)))
    plt.scatter(data[feature],data[target],c='black')
    plt.xlabel('estimator: {}'.format(feature))
    plt.ylabel('target value: {} (predicted)'.format(target))
    plt.show()
##Read crime.csv data set of Boston##
from sklearn.model_selection import cross_val_score
data=pd.read_csv(os.getcwd()+"\\crime.csv",encoding ="ISO-8859-1")
data=data.drop(['OCCURRED_ON_DATE','SHOOTING'],axis=1).head(1000).dropna()#drop useless feature&NaN values
#print(data)
scatter_plot('OFFENSE_CODE','MONTH')#print scatter plot
x5=data[['OFFENSE_CODE','HOUR','Lat','Long']]
y=data['MONTH'].values.reshape(-1,1)

from sklearn.model_selection import GridSearchCV
##Linear Regression
from sklearn.linear_model import LinearRegression
lin_reg=LinearRegression()
MSE5=cross_val_score(lin_reg,x5,y,scoring='neg_mean_squared_error',cv=5)#MSE:degree of difference between actual/predicted value
mean_MSE=np.mean(MSE5)
print('Linear Regression mean-score: ',mean_MSE)#mean score of Linear Regression
 
#Ridge Regression
from sklearn.linear_model import Ridge
ridge=Ridge()
parameters={'alpha':[1e-15,1e-10,1e-8,1e-4,1e-3,1e-2,1,5,10,20]}
ridge_regressor=GridSearchCV(ridge,parameters,scoring='neg_mean_squared_error',cv=5)
ridge_regressor.fit(x5,y)
print('Ridge Regression best-parameter: ',ridge_regressor.best_params_)#best alpha parameter of Ridge Regression
print('Ridge Regression best-score: ',ridge_regressor.best_score_)#best score of Ridge Regression

##Lasso Regression
from sklearn.linear_model import Lasso
lasso=Lasso()
parameters={'alpha':[1e-15,1e-10,1e-8,1e-4,1e-3,1e-2,1,5,10,20]}
lasso_regressor=GridSearchCV(lasso,parameters,scoring='neg_mean_squared_error',cv=5)
lasso_regressor.fit(x5,y)
print('Lasso Regression best-parameter: ',lasso_regressor.best_params_)#best alpha parameter of Lasso Regression
print('Lasso Regression best-score: ',lasso_regressor.best_score_)#best score of Lasso Regression
