import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import warnings
warnings.filterwarnings("ignore")#ignore warnings

arr=np.array([[200,150,50],[250,300,50]])
Table=pd.DataFrame(index=['male','female'],columns=['Republican','Democrat','Independent'],data=arr)
print(Table)

##Scipy library##
from scipy.stats import chi2
from scipy.stats import chi2_contingency
print('[Scipy.chi2 Library]')
stat,p,dof,expected=chi2_contingency(Table)
print(stat,p,dof,expected)
prob=0.95#95% accuracy
critical=chi2.ppf(prob,dof)#critical value is about 5.9914
if abs(stat) >= critical:
    print('Dependent(reject H0)')
else:
    print('Independent(fail to reject H0)')
alpha=1.0-prob
if p<= alpha:
    print('Dependent(reject H0)')
else:
    print('Independent(fail to reject H0')

##Scipy program##
print('[Scipy program]')
#print gender gap,gender preference, 0.05 levelOfSignificance

#sum each Row/Columns of contingency table
addRow=np.zeros(2)
addRow[0]=sum(np.array(Table.loc['male']))
addRow[1]=sum(np.array(Table.loc['female']))
addCol=np.zeros(3)
addCol[0]=sum(np.array(Table['Republican']))
addCol[1]=sum(np.array(Table['Democrat']))
addCol[2]=sum(np.array(Table['Independent']))

#calculate ExpectedValues and statistic from it
ExpectedValues=np.zeros((2,3))
for i in range(2):
    for j in range(3):
        ExpectedValues[i][j]=addRow[i]*addCol[j]/np.sum(addRow)
print('ExpectedValues:\n',ExpectedValues)

statistic=np.zeros((2,3))
for i in range(2):
    for j in range(3):
        statistic[i][j]=pow((Table.iat[i,j]-ExpectedValues[i][j]),2)/ExpectedValues[i][j]
print('statistic:\n',statistic)
print('sum of statistic: ',np.sum(statistic))

dof=(len(Table.index)-1)*(len(Table.columns)-1)
print('Degree of Freedom: ',dof)#Degree of Freedom of table

from scipy import stats
pValue=stats.chi2.pdf(np.sum(statistic),dof)#calculate p-value with scipy funciton
print('p-value: ',pValue)
alpha=1.0-prob
if pValue<= 0.05:
    print('Dependent(reject H0)')
else:
    print('Independent(fail to reject H0')
if np.sum(statistic) >= critical:#reuse critical value from library case
    print('Dependent: there are no difference in gender for votin preference')
else:
    print('Independent: there are difference in gender for votin preference')



