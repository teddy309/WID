import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
import warnings
warnings.filterwarnings("ignore")#ignore warnings

X=np.array([122,131,127,123,132])#scores of Same room
Y=np.array([111,116,113,119,121])#scores of Different room
N=len(X)
table=pd.DataFrame(index=['Scores of Same Room','Scores of Different Room'],data=[X,Y])
print(table)

##Scipy library##
print('[Scipy Library usage]')
from scipy import stats
var_X=X.var(ddof=1)#variance of sample X , delta degree of freedom=1
var_Y=Y.var(ddof=1)#variance of sample Y
print('variance of X:{}, Y:{}'.format(var_X,var_Y))

s=np.sqrt((var_X+var_Y)/2)#standard deviation
t=(X.mean()-Y.mean())/(s*np.sqrt(2/N))#t-Statistic
df=N-1#Degree of Freedom(paired 2sample T test)
p=1-stats.t.cdf(t,df=df)#p-value 
cv=stats.t.ppf(0.975,df=df)#get critical value

#t2,p2=stats.ttest_ind(X,Y)#Independent 2sample T test
t2,p2=stats.ttest_rel(X,Y)#Paired 2sample T test for cross checking with scipy function
print("t= "+str(t2))
print("p= "+str(p2))

if abs(t2) >= cv:
    print('Dependent: get tested in same room get higher score')
else:
    print('Independent: get tested in same room do not support to get higher score')




##Scipy program##
print('[Scipy program]')
DiffXY=np.array(X-Y)
print('difference of scores: ',DiffXY)
powDiff=np.array(pow(DiffXY,2))

sumDiff=np.sum(DiffXY)
sumPow=np.sum(powDiff)

dof=N-1#Degree of Freedom of Paired sample T test
deviationScore=DiffXY-np.mean(DiffXY)#Deviation Score
print('deviation scores: ',deviationScore)
squaredDeviation=pow(deviationScore,2)#Squared Deviation
print('squared deviation: ',squaredDeviation)

S=np.sqrt(np.sum(squaredDeviation)/(N-1))
print('s: ',S)
SM=S/np.sqrt(N)
print('Sm: ',SM)
criticalValue=stats.t.ppf(0.975,df=dof)#get critical value
print('critical value: ',criticalValue)
tStatistic=(np.mean(DiffXY)-np.mean(deviationScore))/SM
print('t-statistic: ',tStatistic)#test statistic

if abs(tStatistic) >= criticalValue:
    print('Dependent: get tested in same room get higher score')
else:
    print('Independent: get tested in same room do not support to get higher score')
