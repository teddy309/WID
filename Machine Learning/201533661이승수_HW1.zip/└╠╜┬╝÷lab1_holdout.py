import pandas as pd
import os
import numpy as np

##Read data & Preprocessing Step##
df=pd.read_csv(os.getcwd()+'\\crimes.csv')
df=df.drop(columns=['OCCURRED_ON_DATE','REPORTING_AREA','Location','SHOOTING'])
df=df.drop(columns=['INCIDENT_NUMBER','OFFENSE_CODE_GROUP','DISTRICT','OFFENSE_DESCRIPTION','DAY_OF_WEEK','UCR_PART','STREET'])
df=df.dropna()#drop unused&null columns

##Training/target dataset & print##
X=df.drop(columns=['MONTH'])#erase target column
y=df['MONTH'].values#target column
print(X.info())

##KNN prediction: holdout sampling##
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
def prediction():
    return 1-knn.score(X_test,y_test)
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=1,stratify=y)
knn=KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train,y_train)
print('holdout score: ',prediction())


