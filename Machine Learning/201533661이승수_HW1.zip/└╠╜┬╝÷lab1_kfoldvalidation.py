import pandas as pd
import os
import numpy as np

##Read data & Preprocessing Step##
df=pd.read_csv(os.getcwd()+'\\crimes.csv')
df=df.drop(columns=['OCCURRED_ON_DATE','REPORTING_AREA','Location','SHOOTING'])
df=df.drop(columns=['INCIDENT_NUMBER','OFFENSE_CODE_GROUP','DISTRICT','OFFENSE_DESCRIPTION','DAY_OF_WEEK','UCR_PART','STREET'])
df=df.dropna()#drop unused&null columns

##Training/target dataset & print##
X=df.drop(columns=['MONTH'])#erase target column
y=df['MONTH'].values#target column
print(X.info())


##KNN prediction: 5-Fold Cross Validation sampling##
from sklearn.model_selection import cross_val_score
from sklearn.neighbors import KNeighborsClassifier
def prediction():
    return 1-np.mean(cv_scores)
knn_cv=KNeighborsClassifier(n_neighbors=3)
cv_scores=cross_val_score(knn_cv,X,y,cv=5)# model, train, target, cross validation
print('cv_scores mean:{}'.format(prediction()))
