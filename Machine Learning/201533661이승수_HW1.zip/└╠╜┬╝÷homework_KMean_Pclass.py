import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
import seaborn as sns
import matplotlib.pyplot as plt
import os

##Import train Data & Feature Engineering##
df=pd.read_csv(os.getcwd()+'\\train.csv')
df=df.dropna()
train=df.drop(['Name','Ticket','Cabin','Embarked'], axis=1)
labelEncoder=LabelEncoder()#encoder to make 'Sex' column into numeric value
labelEncoder.fit(train['Sex'])
train['Sex']=labelEncoder.transform(train['Sex'])

##Import test Data & Feature Engineering##
df=pd.read_csv(os.getcwd()+'\\test.csv')
df=df.dropna()
test=df.drop(['Name','Ticket','Cabin','Embarked'], axis=1)
labelEncoder.fit(test['Sex'])
test['Sex']=labelEncoder.transform(test['Sex'])


##K-Means Prediction##
X=np.array(train.drop(['Survived'],1).astype(float))
y=np.array(train['Survived'])
kmeans=KMeans(algorithm='auto',copy_x =True,init ='k-means++',max_iter=600,n_clusters =2,n_init =10,n_jobs =1,precompute_distances='auto',random_state =None,tol=0.0001,verbose=0)
##Select one of these fit() functions for encrease prediction rate##
kmeans.fit(X,sample_weight=X[:,1])#weight at 'Pclass' column
print("Weight at Pclass")
#kmeans.fit(X,sample_weight=X[:,2])#weight at 'Sex' column
#print("Weight at Sex")
#kmeans.fit(X,y)
#print("Normal prediction")

##Evaluation step##
correct=0#initialize value
for i in range(len(X)):#check prediction correct rate
    predict_me=np.array(X[i].astype(float))
    predict_me=predict_me.reshape(-1,len(predict_me))
    prediction=kmeans.predict(predict_me)
    if prediction[0] == y[i]:
        correct += 1
print("Prediction Rate: ",correct/len(X))#print prediction rate
