import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import DBSCAN

from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import normalize
from sklearn.decomposition import PCA

import seaborn as sns
import matplotlib.pyplot as plt
import os,sys
np.set_printoptions(threshold=sys.maxsize)

##KMeans Parameters##
MI=200 #max_iter: [50,100,200,300]
NC=3 #n_cluster: [2,3,4,5,6]

##Import train Data & Feature Engineering##
csv_data=np.loadtxt(fname='mouse.csv',delimiter=',')
X=np.array(csv_data[:,0])
y=np.array(csv_data[:,1])

##K-Means Prediction##
kmeans=KMeans(algorithm='auto',max_iter=MI,n_clusters =NC)
kmeans.fit(csv_data.reshape(-1,2))
cluster_kmeans=kmeans.predict(csv_data)
print(cluster_kmeans)

plt.title('[Kmeans] max_iter:{}, #cluster:{}'.format(MI,NC))
plt.scatter(X,y,c= cluster_kmeans , s= 60, edgecolor = 'black')
plt.show()


