import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import DBSCAN
import seaborn as sns
import matplotlib.pyplot as plt
import os,sys
np.set_printoptions(threshold=sys.maxsize)


##DBSCAN Parameters##
EPS=0.05 #eps: [0.1,0.002,0.005,0.01,0.02,0.05,0.1,0.2,0.5]
MS=5 #min_samples: [3,5,10,15,20,30,50,100]


##Import train Data & Feature Engineering##
csv_data=np.loadtxt(fname='mouse.csv',delimiter=',')
X=csv_data[:,0]
y=csv_data[:,1]

##DBSCAN & Preprocessing##
DBscan=DBSCAN(eps=EPS,min_samples=MS)
scaler=MinMaxScaler(copy=True, feature_range=(0,1))
scaler.fit(csv_data)
data_normalized=scaler.transform(csv_data)
#print(csv_data[:,0].min(),csv_data[:,0].max())
#print(csv_data[:,1].min(),csv_data[:,1].max())
#print(data_normalized[:,0].min(),data_normalized[:,0].max())
#print(data_normalized[:,1].min(),data_normalized[:,1].max())
#print(data_normalized)
cluster_dbscan=DBscan.fit_predict(data_normalized)
print(cluster_dbscan)

plt.title('[DBSCAN] eps:{}, #min_samples:{}'.format(EPS,MS))
plt.scatter(X,y,c= cluster_dbscan , s= 60, edgecolor = 'black')
plt.show()

