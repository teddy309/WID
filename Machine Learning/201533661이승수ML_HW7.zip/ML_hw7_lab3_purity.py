import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import DBSCAN
import seaborn as sns
import matplotlib.pyplot as plt
import os,sys
np.set_printoptions(threshold=sys.maxsize)

##DBSCAN Parameters##
EPS=[0.001,0.002,0.005,0.01,0.02,0.05,0.1,0.2,0.5]
MS=[3,5,10,15,20,30,50,100]
DM=['euclidean','hamming']

maxClusterSize=10 #regulate max-cluster size used at purity()
##Purity: return purity under the given DBSCAN Parameters(EPS,MS,DM)
def purity(clusteredData):
    numCluster=np.zeros(maxClusterSize)
    numOutlier=0
    clusterTargetCheck=np.zeros([maxClusterSize,2])
    for i in range(len(clusteredData)):
        if clusteredData[i] is -1:
            numOutlier=numOutlier+1
        elif clusteredData[i]>=maxClusterSize:
            numOutlier=numOutlier+1
        elif clusteredData[i]<0:
            numOutlier=numOutlier+1
        else: #correctly clustered cases
            numCluster[clusteredData[i]]=numCluster[clusteredData[i]]+1
            if y[i] is "p":
                clusterTargetCheck[clusteredData[i],0]=clusterTargetCheck[clusteredData[i],0]+1
            else:
                clusterTargetCheck[clusteredData[i],1]=clusterTargetCheck[clusteredData[i],1]+1
    #print('numOutlier: {},numCluster: {}'.format(numOutlier,numCluster))
    purityPE=np.zeros(maxClusterSize)
    for i in range(maxClusterSize):
        purityPE[i]=purityPE[i]+max(clusterTargetCheck[i,0],clusterTargetCheck[i,1])
    return sum(purityPE)/len(clusteredData)




##Import train Data & Feature Engineering##
csv_data=pd.read_csv(os.getcwd()+'\\mushrooms.csv')

#22 predictors
label=['cap-shape','cap-surface','cap-color','bruises','odor','gill-attachment','gill-spacing','gill-size','gill-color','stalk-shape','stalk-root','stalk-surface-above-ring','stalk-surface-below-ring','stalk-color-above-ring','stalk-color-below-ring','veil-type','veil-color','ring-number','ring-type','spore-print-color','population','habitat']
X=csv_data.drop(columns=['class']).head(100)#test:predictors
y=csv_data['class'].head(100)



##Preprocessing Step##
##Preprocessing: Encoding Dataframe##
#case1~3: LabelEncoder
enc=LabelEncoder()
for i in range(len(label)):
    testCol=X[label[i]]
    Xout=enc.fit_transform(testCol[:,np.newaxis])
    #print(label[i],Xout[1],X.loc[1,label[i]])
    for j in range(len(Xout)):
        X.loc[j,label[i]]=Xout[j]
'''
#case4: none
'''     
##Preprocessing:Scaling Dataframe##
#case1: MinMaxScaler
scaler=MinMaxScaler(copy=True, feature_range=(0,1))#scaler1: MinMaxScaler
scaler.fit(X,y)
X_normalized=scaler.fit_transform(X)
#case2: StandardScaler
scaler=StandardScaler()#scaler2: StandardScaler
scaler.fit(X,y)
X_normalized=scaler.fit_transform(X)
'''
#case3,4: none
X_normalized=X
'''


##update best 3 purity for new computed purity value
def getBest3Purity(curBest,newPurity):
    if curBest[2]<newPurity:
        if curBest[1]<newPurity:
            if curBest[0]<newPurity:
                if newPurity is 0.9:
                    print('##########################best3:{},newPurity:{}'.format(curBest,newPurity))
                curBest.insert(0,newPurity)
                curBest.pop()
                print('changed[0], curBest: ',curBest)
                return curBest
            else:
                curBest.insert(1,newPurity)
                curBest.pop()
                print('changed[1], curBest: ',curBest)
                return curBest

        else:
            curBest.insert(2,newPurity)
            curBest.pop()
            print('changed[2], curBest: ',curBest)
            return curBest
    else:
        return curBest

##Prediction Step##
bestPurity=0
best3=[0,0,0]#np.zeros(3)
for param_eps in range(len(EPS)):
    for param_ms in range(len(MS)):
        for param_dm in range(len(DM)):
            DBscan=DBSCAN(eps=EPS[param_eps],min_samples=MS[param_ms],metric=DM[param_dm],p=3)
            cluster_dbscan=DBscan.fit_predict(X_normalized)
            print('purity(EPS:{},minSample:{},DistMeasure:{}): {}'.format(EPS[param_eps],MS[param_ms],DM[param_dm],purity(cluster_dbscan)))
            best3=getBest3Purity(best3,purity(cluster_dbscan)) #max(bestPurity,purity(cluster_dbscan))
print('-----------------------------------')
print('Best Purity(encoder:{},scaler:{})= {}'.format('LabelEncoder','none',best3))



