import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import os,sys #os.getcwd()
import random #random.choice()
np.set_printoptions(threshold=sys.maxsize)

#from sklearn.cluster import KMeans
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
#from sklearn.preprocessing import normalize
#from sklearn.decomposition import PCA

##Parameter##
kSize=12#K: Number of clusters(user input)


##Purity: return purity under the given KModes clustered data in each kSize
#params: clusteredData(list)
#return: purity(float)
def purity(clusteredData):
    y=csv_data['class']
    numCluster=np.zeros(kSize)
    numOutlier=0
    clusterTargetCheck=np.zeros([kSize,2])
    for i in range(len(clusteredData)):
        if clusteredData[i] is -1: #case: outliers
            numOutlier=numOutlier+1
        elif clusteredData[i]>=kSize: 
            numOutlier=numOutlier+1
        elif clusteredData[i]<0: 
            numOutlier=numOutlier+1
        else: #correctly clustered cases
            numCluster[clusteredData[i]]=numCluster[clusteredData[i]]+1
            if y[i] is "p":
                clusterTargetCheck[clusteredData[i],0]=clusterTargetCheck[clusteredData[i],0]+1
            else:
                clusterTargetCheck[clusteredData[i],1]=clusterTargetCheck[clusteredData[i],1]+1
    #print('numOutlier: {},numCluster: {}'.format(numOutlier,numCluster))
    purityPE=np.zeros(kSize)
    for i in range(kSize):
        purityPE[i]=purityPE[i]+max(clusterTargetCheck[i,0],clusterTargetCheck[i,1])
    return sum(purityPE)/len(clusteredData)


##return hamming distance between list1(row) and list2(center)
#params: list1(row_list),list2(center_list)
#return: hammingDistance(float)
def hammingDist(list1,list2):
    diff=0
    if len(list1)!=len(list2):
        return max(len(list1),len(list2))
    for att1,att2 in zip(list1,list2):
        if att1 != att2:
            diff=diff+1
    return diff
##return dissimilarity distance between list1(row) and list2(center)
#params: list1(row_list),list2(center_list)
#return: dissimilarityDistance(float)
def dissimilarityDist(list1,list2):
    diff=0
    if len(list1)!=len(list2):
        return max(len(list1),len(list2))
    for att1,att2 in zip(list1,list2):
        if att1 == att2:
            diff=diff+(1-1/3)#1-Nr/N
        elif att1 != att2:
            diff=diff+1
    return diff

##return distance between each rows and center of centroids
#params: row(index_int),modes(index_int),distFunc('Hamming','dissimilarity'_str)
#return: calculated distance(float)
def distance(row,modes,distFunc):
    distances=[]
    if distFunc=='Hamming':
        for i in range(len(modes)):
            distances.append(hammingDist(list(row),list(modes[i])))
        #print('distances: ',distances)
        return distances.index(min(distances))
    elif distFunc=='dissimilarity':
        for i in range(len(modes)):
            distances.append(dissimilarityDist(list(row),list(modes[i])))
        return distances.index(min(distances))

##return distance between each rows and center of centroids
#params: DF(csv_data_pd.DataFrame),K(kSize_int),distFunc('Hamming','dissimilarity'_str)
#return: calculated distance(float)
def getRandomCenter(DF,K,distFunc):
    randomIndex=[] #random cluster-center's indices
    clusterModes=[] 
    #step1: select K modes in random selection
    for i in range(K):
        randomIndex.append(random.choice(range(len(DF))))
        clusterModes.append(DF.loc[randomIndex[i]])
        #print('cluster[{}]_row{}: {}'.format(i,randomIndex[i],list(clusterModes[i])))
    return [randomIndex,clusterModes]
    

##Kmodes function:
#params: DF(csv_data_pd.DataFrame),K(kSize_int),distFunc('Hamming','dissimilarity'_str)
#return: kmodes cluster(list)
def Kmodes(DF,K,distFunc):
    #step1: select K modes in random selection
    initialCenter=getRandomCenter(DF,K,distFunc) #initialCenter[0]:index(list_int), [1]:modes(list_pd.Series)
            
    #step2: assign objects to clusters with minimum distance
    cluster=[]
    for i in range(len(DF)):
        #print(i,'th row:')
        if i not in initialCenter[0]:
            cluster.append(distance(DF.loc[i],initialCenter[1],distFunc))
        else:
            for j in range(K):
                if i==initialCenter[0][j]:
                    cluster.append(j)
                    
    #step3: check cluster
    return cluster
    


##Main: Import train Data & Feature Engineering##
csv_data=pd.read_csv(os.getcwd()+'\\mushrooms.csv')#.head(100)

maxPurity=0
index=0
for i in range(2,10):
    kSize=i
    clustered_data=Kmodes(csv_data,kSize,'Hamming') #params: dataset, K, hamming function
    #clustered_data=Kmodes(csv_data,kSize,'dissimilarity') #params: dataset, K, dissimilarity function
    
    print('cluster: ',clustered_data)
    Purity=purity(clustered_data)
    print('kSize:{}, purity:{} '.format(kSize,Purity))
    if maxPurity<Purity:
        maxPurity=Purity
        index=i
print('maxPurity:{} at index:{}'.format(maxPurity,index))



